package com.kaupenjoe.mccourse.data;

import com.kaupenjoe.mccourse.MCCourseMod;
import net.minecraft.data.DataGenerator;
import net.minecraftforge.common.data.LanguageProvider;

public class ModLanguageProvider extends LanguageProvider
{
    public ModLanguageProvider(DataGenerator gen, String locale)
    {
        super(gen, MCCourseMod.MOD_ID, locale);
    }

    @Override
    protected void addTranslations()
    {
        String locale = this.getName().replace("Languages: ", "");

        switch (locale)
        {
            case "en_us":
                add("item.mccourse.copper_ingot", "Copper Ingot");
                add("advancements.story.copper_block.title", "Coppering");
                add("advancements.story.copper_block.description", "Acquire Copper Blocks");
                break;
            default:
                break;
        }
    }
}

package com.kaupenjoe.mccourse.item;

import com.kaupenjoe.mccourse.item.weapon.BluntItem;
import net.minecraft.item.IItemTier;

public class CopperClub extends BluntItem
{
    public CopperClub(IItemTier tier, int attackDamageIn, float attackSpeedIn, Properties builderIn)
    {
        super(tier, attackDamageIn, attackSpeedIn, builderIn);
    }
}
